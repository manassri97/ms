package com.capgemini.bookstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.bookstore.beans.CustomerReview;

public interface IBookstoreCustomerReviewDAO extends JpaRepository<CustomerReview, Integer> {

}
