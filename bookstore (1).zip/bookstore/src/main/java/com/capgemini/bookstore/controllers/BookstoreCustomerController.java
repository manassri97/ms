package com.capgemini.bookstore.controllers;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class BookstoreCustomerController {

}
