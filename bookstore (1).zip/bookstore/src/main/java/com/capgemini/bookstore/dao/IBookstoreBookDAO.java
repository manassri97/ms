package com.capgemini.bookstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.bookstore.beans.BookDetails;

public interface IBookstoreBookDAO extends JpaRepository<BookDetails, Integer> {

}
