package com.capgemini.bookstore.service;

public class IBookstoreAdminServiceImpl implements IBookstoreAdminService {

	}
